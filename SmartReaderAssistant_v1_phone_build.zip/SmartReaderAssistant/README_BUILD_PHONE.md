# بناء APK من الهاتف فقط

هذا المشروع يحتوي على Workflow جاهز لـ GitHub Actions. لا تحتاج إلى حاسوب.

1. من الهاتف افتح GitHub وأنشئ حسابًا أو سجّل الدخول.
2. أنشئ Repository جديدًا باسم `SmartReaderAssistant` واجعله Private إذا أردت.
3. ارفع **محتويات مجلد SmartReaderAssistant** إلى المستودع، وليس ملف ZIP نفسه. يمكن استخدام زر `Add file` ثم `Upload files` من متصفح الهاتف.
4. بعد رفع الملفات، افتح تبويب `Actions`.
5. اختر `Build Smart Reader Assistant APK` ثم `Run workflow`.
6. انتظر حتى تصبح العملية خضراء.
7. افتح الـworkflow الناجح، ثم قسم `Artifacts`، واضغط `SmartReaderAssistant-debug` لتنزيل APK.
8. ثبّت APK على هاتفك.

بعد التثبيت:
- افتح التطبيق مرة واحدة.
- اضغط زر تفعيل خدمة الوصول Accessibility.
- فعّل خدمة `Smart Reader Assistant`.
- افتح SmartMobility ووصل إلى شاشة `Nouvel Index (m³)`.
- ارجع للمساعد، أدخل رقمًا تجريبيًا مثل `638` واضغط `Envoyer à SmartMobility`.

ملاحظة: هذه نسخة اختبارية. نجاح الإدخال التلقائي يعتمد على ما إذا كانت خانة SmartMobility تسمح لـ Android Accessibility بخاصية SET_TEXT. إذا لم تعمل، سنضيف مسارًا بديلًا يعتمد على تحديد الحقل واللصق.
