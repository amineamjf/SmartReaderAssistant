package com.smartreader.assistant;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
    EditText search,newIndex; ListView results; TextView details,status; ArrayList<Meter> all=new ArrayList<>(), shown=new ArrayList<>();
    ArrayAdapter<String> adapter;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
        search=findViewById(R.id.search);newIndex=findViewById(R.id.newIndex);results=findViewById(R.id.results);details=findViewById(R.id.details);status=findViewById(R.id.status);
        load(); adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,new ArrayList<String>());results.setAdapter(adapter); filter("");
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){filter(s.toString());}public void afterTextChanged(android.text.Editable e){}});
        results.setOnItemClickListener((p,v,pos,id)->{Meter m=shown.get(pos);details.setText("Compteur: "+m.meter+"\nContrat: "+m.contract+"\nClient: "+m.client+"\nAdresse: "+m.address+"\nAncien Index: "+m.old);});
        findViewById(R.id.send).setOnClickListener(v->{String x=newIndex.getText().toString().trim();if(x.isEmpty()){newIndex.setError("أدخل المؤشر الجديد");return;}send(x);});
        findViewById(R.id.access).setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception e){}});
        handle(getIntent());
    }
    void handle(Intent i){if(i!=null&&i.getData()!=null&&"smartreaderassistant".equals(i.getData().getScheme())){String x=i.getData().getQueryParameter("index");if(x!=null){newIndex.setText(x);newIndex.setSelection(x.length());}}}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);handle(i);}
    void send(String x){Intent i=new Intent(MeterAccessibilityService.ACTION_SEND);i.setPackage(getPackageName());i.putExtra("index",x);sendBroadcast(i);Toast.makeText(this,"تم إرسال المؤشر للمساعد",Toast.LENGTH_SHORT).show();}
    void load(){try(BufferedReader r=new BufferedReader(new InputStreamReader(getAssets().open("meters.csv"),"UTF-8"))){String line;r.readLine();while((line=r.readLine())!=null){List<String> a=parse(line);if(a.size()>=7)all.add(new Meter(a.get(0),a.get(1),a.get(2),a.get(3),a.get(4),a.get(5),a.get(6)));}}catch(Exception e){status.setText("خطأ في تحميل بيانات العدادات: "+e.getMessage());}}
    List<String> parse(String s){ArrayList<String>a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(char c:s.toCharArray()){if(c=='"')q=!q;else if(c==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(c);}a.add(b.toString());return a;}
    void filter(String q){shown.clear();String z=q.toLowerCase(Locale.ROOT);for(Meter m:all){if(z.isEmpty()||m.meter.toLowerCase().contains(z)||m.contract.toLowerCase().contains(z)||m.client.toLowerCase().contains(z)||m.address.toLowerCase().contains(z)){shown.add(m);if(shown.size()>=100)break;}}adapter.clear();for(Meter m:shown)adapter.add(m.meter+" | "+m.contract+" | "+m.client);adapter.notifyDataSetChanged();status.setText("عدادات: "+all.size()+" — نتائج البحث: "+shown.size());}
    static class Meter{String no,type,contract,meter,client,address,old;Meter(String a,String b,String c,String d,String e,String f,String g){no=a;type=b;contract=c;meter=d;client=e;address=f;old=g;}}
}
