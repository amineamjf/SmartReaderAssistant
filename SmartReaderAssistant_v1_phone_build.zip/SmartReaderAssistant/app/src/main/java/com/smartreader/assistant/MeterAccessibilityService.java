package com.smartreader.assistant;

import android.accessibilityservice.AccessibilityService;import android.view.accessibility.AccessibilityNodeInfo;import android.view.accessibility.AccessibilityEvent;import android.content.*;import android.os.*;import java.util.*;

public class MeterAccessibilityService extends AccessibilityService {
 public static final String ACTION_SEND="com.smartreader.assistant.SEND_INDEX"; private String targetPackage=""; private String pending=""; private Handler h=new Handler(Looper.getMainLooper());
 private final BroadcastReceiver rx=new BroadcastReceiver(){public void onReceive(Context c,Intent i){if(ACTION_SEND.equals(i.getAction())){pending=i.getStringExtra("index"); if(targetPackage!=null&&!targetPackage.isEmpty()){try{Intent launch=getPackageManager().getLaunchIntentForPackage(targetPackage);if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(launch);}}catch(Exception e){} h.postDelayed(()->tryFill(),1200);}else tryFill();}}};
 @Override public void onServiceConnected(){super.onServiceConnected();registerReceiver(rx,new IntentFilter(ACTION_SEND),Context.RECEIVER_NOT_EXPORTED);}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){CharSequence p=e.getPackageName();if(p==null||p.toString().equals(getPackageName()))return;AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;if(hasNouvelIndex(root)){targetPackage=p.toString();tryFill();}}
 boolean hasNouvelIndex(AccessibilityNodeInfo n){if(n==null)return false;String t=text(n);if(t.toLowerCase(Locale.ROOT).contains("nouvel index")||t.toLowerCase(Locale.ROOT).contains("index (m³)"))return true;for(int i=0;i<n.getChildCount();i++)if(hasNouvelIndex(n.getChild(i)))return true;return false;}
 void tryFill(){if(pending==null||pending.isEmpty())return;AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;AccessibilityNodeInfo edit=findEdit(root);if(edit!=null){edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS);Bundle a=new Bundle();a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,pending);if(edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,a)){pending="";}}}
 AccessibilityNodeInfo findEdit(AccessibilityNodeInfo n){if(n==null)return null;String t=(text(n)+" "+String.valueOf(n.getHintText())+" "+String.valueOf(n.getContentDescription())).toLowerCase(Locale.ROOT);if(n.isEditable()&&(t.contains("nouvel index")||t.contains("index")))return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo x=findEdit(n.getChild(i));if(x!=null)return x;}return null;}
 String text(AccessibilityNodeInfo n){CharSequence a=n.getText();return a==null?"":a.toString();}
 @Override public void onInterrupt(){}
 @Override public void onDestroy(){try{unregisterReceiver(rx);}catch(Exception e){}super.onDestroy();}
}
